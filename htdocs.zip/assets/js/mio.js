

$('#carousel-example-generic').carousel();